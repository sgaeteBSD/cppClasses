#include "Media.h"

class Music : public Media {
private:
  char* artist;
  char* publisher;
  int duration;
public:
  Music(char* title, int year, char* artist, char* publisher, int duration);
  virtual ~Music();

  void print();

  char* getArtist();
  char* getPublisher();
  int getDuration();
};
